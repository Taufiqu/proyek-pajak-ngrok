import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import MainOCRPage from "./components/MainOCRPage";
import HistoryPage from "./components/HistoryPage";
import "./App.css";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
    <Router>
      <div className="App">
        <nav style={{ marginBottom: "20px" }}>
          <Link to="/">🧾 OCR</Link> | <Link to="/history">📜 Laporan</Link>
        </nav>

        <Routes>
          <Route path="/" element={<MainOCRPage />} />
          <Route path="/history" element={<HistoryPage />} />
        </Routes>

        <ToastContainer />
      </div>
    </Router>
  );
}

export default App;
