import React from "react";
import { Link } from "react-router-dom";
import "../App.css";

const Layout = ({ children }) => {
  return (
    <div className="container">
      <nav className="navbar">
        <Link to="/" className="nav-link">🧾 OCR</Link>
        <Link to="/history" className="nav-link">📜 Laporan</Link>
      </nav>
      <main>{children}</main>
    </div>
  );
};

export default Layout;
