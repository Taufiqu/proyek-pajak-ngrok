import React from "react";

const UploadForm = ({
  handleUpload,
  namaPtUtama,
  setNamaPtUtama,
  selectedFiles,
  setSelectedFiles,
}) => {
  const handleAddFile = (e) => {
    const newFile = Array.from(e.target.files);
    if (newFile.length > 0) {
      setSelectedFiles((prev) => [...prev, ...newFile]);
    }
  };

  const triggerUpload = () => {
    document.getElementById("uploadInput").click();
  };

  return (
    <form onSubmit={handleUpload} className="form-validator">
      <label>
        Nama PT Utama:
        <input
          type="text"
          value={namaPtUtama}
          onChange={(e) => setNamaPtUtama(e.target.value)}
          required
        />
      </label>

      {/* Hidden file input */}
      <input
        id="uploadInput"
        type="file"
        accept=".pdf, image/*"
        style={{ display: "none" }}
        onChange={handleAddFile}
      />

      {/* Tombol untuk trigger upload pertama atau tambahan */}
      <button type="button" onClick={triggerUpload}>
        📁 Pilih File
      </button>

      {/* Tampilkan list file */}
      {selectedFiles.length > 0 && (
        <ul>
          {selectedFiles.map((file, index) => (
            <li key={index}>{file.name}</li>
          ))}
        </ul>
      )}

      {!namaPtUtama && (
        <p className="error-text">⚠️ Nama PT belum diisi</p>
      )}

      {/* Tombol submit upload */}
      <button
        type="submit"
        disabled={!namaPtUtama || selectedFiles.length === 0}
        title={
          !namaPtUtama
            ? "Isi nama PT dulu"
            : selectedFiles.length === 0
            ? "Belum ada file terpilih"
            : ""
        }
      >
        Upload & Proses
      </button>
    </form>
  );
};
export default UploadForm;
